package com.su.cevreilcesuanalizleri.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.su.cevreilcesuanalizleri.R

class WaterListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_water_list)
    }
}